# paginas/views.py
from django.shortcuts import render, redirect
from .forms import LaboratorioForm, ObservacaoForm
from .models import Laboratorio, Observacao
from django.contrib.auth.decorators import login_required, user_passes_test

def is_admin(user):
    return user.is_staff

# paginas/views.py

@login_required
@user_passes_test(is_admin)
def listar_laboratorios(request):
    laboratorios = Laboratorio.objects.all()
    return render(request, 'paginas/listar_laboratorios.html', {'laboratorios': laboratorios})


@login_required
@user_passes_test(is_admin)
def cadastrar_laboratorio(request):
    if request.method == 'POST':
        form = LaboratorioForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_laboratorios')
    else:
        form = LaboratorioForm()
    return render(request, 'cadastrar_laboratorio.html', {'form': form})

@login_required
def cadastrar_observacao(request):
    if request.method == 'POST':
        form = ObservacaoForm(request.POST)
        if form.is_valid():
            observacao = form.save(commit=False)
            observacao.usuario = request.user
            observacao.save()
            return redirect('listar_observacoes')
    else:
        form = ObservacaoForm()
    return render(request, 'cadastrar_observacao.html', {'form': form})

@login_required
def listar_observacoes(request):
    observacoes = Observacao.objects.filter(usuario=request.user)
    return render(request, 'listar_observacoes.html', {'observacoes': observacoes})

# paginas/views.py
from django.shortcuts import render, redirect

def pagina_inicial(request):
    return redirect('listar_laboratorios')  # Ou redirecione para outra URL se desejar

