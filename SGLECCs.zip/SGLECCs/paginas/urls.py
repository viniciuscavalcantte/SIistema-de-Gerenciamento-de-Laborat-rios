# leccs/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.pagina_inicial, name='pagina_inicial'),  # Define a URL base
    path('laboratorios/', views.listar_laboratorios, name='listar_laboratorios'),
    path('laboratorios/novo/', views.cadastrar_laboratorio, name='cadastrar_laboratorio'),
    path('observacoes/', views.listar_observacoes, name='listar_observacoes'),
    path('observacoes/nova/', views.cadastrar_observacao, name='cadastrar_observacao'),
]