# paginas/forms.py
from django import forms
from .models import Laboratorio, Observacao

class LaboratorioForm(forms.ModelForm):
    class Meta:
        model = Laboratorio
        fields = ['nome', 'localizacao']

class ObservacaoForm(forms.ModelForm):
    class Meta:
        model = Observacao
        fields = ['laboratorio', 'texto']
